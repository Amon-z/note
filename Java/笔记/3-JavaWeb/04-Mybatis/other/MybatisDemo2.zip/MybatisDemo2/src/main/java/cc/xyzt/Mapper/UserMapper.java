package cc.xyzt.Mapper;

import cc.xyzt.User;

import java.util.List;

public interface UserMapper {

    List<User> selectAll();
}
